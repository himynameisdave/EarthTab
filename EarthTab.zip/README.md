### Build

Your build will appear here (in your dev environment) after running `gulp build` at the root of the repo. If you have not installed the nessesary dependencies, you can do so by running `npm i` from the root.

The files are gitignored because they are redunant and can be built by anyone who has the repo anyway. The build also gets zipped (so that it can be shared and uploaded to Google's Chrome Web Store) so the files are also there.
